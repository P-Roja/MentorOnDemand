import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { LoginComponent } from './login/login.component';
import { MentorRegistrationComponent } from './mentor-registration/mentor-registration.component';
import { AdminLandingComponent } from './admin-landing/admin-landing.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import { MentorLandingComponent } from './mentor-landing/mentor-landing.component';

const routes: Routes = [
  {path:'' , component:LoginComponent,pathMatch:'full'},
  {path:'UserRegistration' , component:UserRegistrationComponent},
  {path:'LoginComponent' , component:LoginComponent},
  {path:'MentorRegistration' , component:MentorRegistrationComponent},
  {path:'AdminLandingComponent' , component:AdminLandingComponent},
  {path:'UserLandingComponent' , component:UserLandingComponent},
  {path:'MentorLandingComponent' , component:MentorLandingComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]
})
export class AppRoutingModule { }
