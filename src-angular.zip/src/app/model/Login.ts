export class Login{

role:string;
    email:string;
    password:string;
    access:any;
}