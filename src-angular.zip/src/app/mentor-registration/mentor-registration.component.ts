import { Component, OnInit } from '@angular/core';
import { mentor } from '../model/mentor';
import { Router } from '@angular/router';
import { MentorService } from '../service/mentor.service';

@Component({
  selector: 'app-mentor-registration',
  templateUrl: './mentor-registration.component.html',
  styleUrls: ['./mentor-registration.component.css']
})
export class MentorRegistrationComponent implements OnInit {
 mentor : mentor =new mentor();
  insert:any;
 submitted=false;
  constructor(private router: Router,private mentorService :MentorService) { }
  ngOnInit() {
  }

  save(){
    console.log(this.submitted);
    this.mentorService.createMentor(this.mentor)
    .subscribe(data=>console.log(data),error=>console.log(error));
    this.mentor=new mentor();
    console.log(this.insert);
   
      console.log('aassa');
      this.router.navigate(['LoginComponent']);
    
  }
  onSubmit(){
    console.log(this.mentor);
    console.log(this.submitted);
    this.submitted=true;
    this.save();
  }
}
