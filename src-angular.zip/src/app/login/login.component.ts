import { Component, OnInit } from '@angular/core';
import { Login } from '../model/Login';

import { Router } from '@angular/router';
import { LoginService } from '../service/LoginService';
import { mentor } from '../model/mentor';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login : Login =new Login();
  mentor :mentor =new mentor();
  insert: any;
  searchResult:any [];
    value:any;

 submitted=false;
  constructor(private router: Router,private loginService :LoginService) { }
  
  save(){
    console.log(this.submitted);
    this.loginService.createMentor(this.login)
    .subscribe(data=>{
      if(data==1)
      {
       this.router.navigate(['UserLandingComponent']);
      }
      else if(data==2)
      {
       this.router.navigate(['MentorLandingComponent']);
      }
     else  if(data==3)
      {
       this.router.navigate(['AdminLandingComponent']);
      }
        else{
         this.router.navigate(['LoginComponent']);
        }
    }
      );
    this.login=new Login();
   
  
    
  }
  onSubmit(){
    console.log(this.login);
    console.log(this.submitted);
    this.submitted=true;
    this.save();
  }
  ngOnInit() {
    /*this.loginService.createMentor(this.login)
    .subscribe(data=>this.insert=data,error=>console.log(error));
    console.log(this.insert);*/
  }
OnSearch()
{
  console.log('search ')
this.loginService.getMentorBySkills(this.mentor)

.subscribe( (res:any[])=>{
  console.log('onserach ',res[0].course)
  this.searchResult=res;
  console.log(this.searchResult);
})
}
}
